const axios = require('axios');

const options = {
  method: 'GET',
  url: 'https://next-parking-lot.p.rapidapi.com/location/tags/28588151',
  headers: {
    'X-RapidAPI-Key': 'SIGN-UP-FOR-KEY',
    'X-RapidAPI-Host': 'next-parking-lot.p.rapidapi.com'
  }
};

try {
	const response = await axios.request(options);
	console.log(response.data);
} catch (error) {
	console.error(error);
}